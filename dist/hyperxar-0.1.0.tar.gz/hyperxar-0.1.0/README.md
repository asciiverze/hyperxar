# hyperxar

Ein Python3 Modul zum Kopieren, Komprimieren und Erstellen von ISO-Images mit Fortschrittsanzeige (`tqdm`).

## Installation

```bash
pip install git+https://github.com/deinusername/hyperxar.git
